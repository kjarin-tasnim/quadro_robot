from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from ament_index_python.packages import get_package_share_directory
from launch.substitutions import PathJoinSubstitution
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():

    sim_time = True
    ign_pkg_share = get_package_share_directory('ros_gz_sim')
    quadro_desc_pkg_share = get_package_share_directory('quadro_description')
    control_pkg_share = get_package_share_directory('quadro_control')

    gz_sim_launch = PathJoinSubstitution(
        [ign_pkg_share, 'launch', 'gz_sim.launch.py']
    )

    spawn_entity_launch = PathJoinSubstitution(
        [quadro_desc_pkg_share, 'launch', 'spawn.launch.py']
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(gz_sim_launch),
        launch_arguments={'gz_args': 'empty.sdf'}.items(),
    )

    spawn_entity = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(spawn_entity_launch),
    )

    controllers = PathJoinSubstitution(
        [control_pkg_share, 'config', 'controllers.yaml']
    )

    control_node = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[controllers],
        output='screen',
        remappings=[
            ('~/robot_description', '/robot_description')
        ]
        
    )


    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
        output='screen',
    )

    robot_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['leg_position_controller', '--controller-manager', '/controller_manager'],
        output='screen',
    )

    # leg1_controller_spawner = Node(
    #     package='controller_manager',
    #     executable='spawner',
    #     arguments=['leg_1_controller', '--controller-manager', '/controller_manager'],
    #     output='screen',
    # )

    # leg2_controller_spawner = Node(
    #     package='controller_manager',
    #     executable='spawner',
    #     arguments=['leg_2_controller', '--controller-manager', '/controller_manager'],
    #     output='screen',
    # )
    # leg3_controller_spawner = Node(
    #     package='controller_manager',
    #     executable='spawner',
    #     arguments=['leg_3_controller', '--controller-manager', '/controller_manager'],
    #     output='screen',
    # )
    # leg4_controller_spawner = Node(
    #     package='controller_manager',
    #     executable='spawner',     
    #     arguments=['leg_4_controller', '--controller-manager', '/controller_manager'],
    #     output='screen',
    # )

    # base_to_actuator_controller_spawner = Node(
    #     package='controller_manager',
    #     executable='spawner',
    #     arguments=['base_to_actuator_controller', '--controller-manager', '/controller_manager'],
    #     output='screen',
    # )







    return LaunchDescription([
        gazebo,
        spawn_entity,
        control_node,
        joint_state_broadcaster_spawner,
        robot_controller_spawner,
        # leg1_controller_spawner,
        # leg2_controller_spawner,
        # leg3_controller_spawner,
        # leg4_controller_spawner,
        # base_to_actuator_controller_spawner,
    ])